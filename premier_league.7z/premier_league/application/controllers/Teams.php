<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teams extends CI_Controller {

	public function __construct()
        {
                parent::__construct();
                $this->load->model('teams_model');
                $this->load->helper('url_helper');
        }
        
	public function index()
	{
		$data['teams'] = $this->teams_model->get_teams();
	}
        public function view($slug = NULL)
        {
                $data['team'] = $this->teams_model->get_teams($slug);
                $data['title'] = 'Registered Teams';

                $this->load->view('templates/header', $data);
                $this->load->view('teams/index', $data);
                $this->load->view('templates/footer');
        }
        public function create()
    {
        $this->load->helper('form');
        $this->load->library('form_validation');

        $data['title'] = 'Create a team';

        $this->form_validation->set_rules('name', 'Team Name', 'required');

        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('templates/header', $data);
            $this->load->view('teams/create');
            $this->load->view('templates/footer');

        }
        else
        {
            $this->teams_model->set_teams();
            $this->load->view('teams/success');
        }
    }
}
