<h2><?php echo $title; ?></h2>

<?php foreach ($teams as $team_item): ?>

        <h3><?php echo $team_item['id']; ?></h3>
        <div class="main">
                <?php echo $team_item['name']; ?>
        </div>
        <p><a href="<?php echo site_url('premier_league/'.$team_item['slug']); ?>">View Team Standing</a></p>

<?php endforeach; ?>