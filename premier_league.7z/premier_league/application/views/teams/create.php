<h2><?php echo $title; ?></h2>

<?php echo validation_errors(); ?>

<?php echo form_open('teams/create'); ?>

    <label for="title">Team Name</label>
    <input type="text" name="name" /><br />    

    <input type="submit" name="submit" value="Create team" />

</form>