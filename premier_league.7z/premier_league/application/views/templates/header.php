<html>
        <head>
                <title>Premier League</title>
        </head>
        <body>

                <h1><?php echo $title; ?></h1>