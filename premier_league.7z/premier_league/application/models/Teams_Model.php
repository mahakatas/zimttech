<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */


class Teams_Model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }
        
        public function get_teams($slug = FALSE)
        {
            if ($slug === FALSE)
            {
                    $query = $this->db->get('teams');
                    return $query->result_array();
            }

            $query = $this->db->get_where('teams', array('slug' => $slug));
            return $query->row_array();
        }
        public function set_teams()
        {
            $this->load->helper('url');

            $slug = url_title($this->input->post('title'), 'dash', TRUE);

            $data = array(
                
                'team_name' => $this->input->post('name')
            );

            return $this->db->insert('teams', $data);
        }
}